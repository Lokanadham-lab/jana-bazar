JANA BAZAR PRO V3 FINAL COMPLETE
Upload index.html as the production entry file.
The logo is embedded in index.html, so the HTML works as a single-file upload.
Real OTP/SMS/WhatsApp, payments, wallet money, BBPS and delivery providers require secure backend Edge Functions and webhooks.
Never place service-role/payment/SMS/WhatsApp/BBPS provider secrets in index.html.
